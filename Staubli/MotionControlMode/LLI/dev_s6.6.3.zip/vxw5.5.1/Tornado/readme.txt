To speedup link, you can use the file defs.gnu int the directory:
C:\Tornado2.2\target\h\tool\gnu
